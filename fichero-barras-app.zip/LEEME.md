# Fichero de Barras

App web instalable para escanear códigos de barras y guardar la ficha de cada producto.
Los datos quedan guardados en el celular (no hay servidor).

## Cómo publicarla gratis en GitHub Pages

1. Creá una cuenta en https://github.com (si todavía no tenés).
2. Creá un repositorio nuevo, público, con el nombre que quieras (por ejemplo `fichero-barras`).
3. Subí todos los archivos de esta carpeta a la raíz del repositorio (botón "Add file" > "Upload files").
4. Entrá a Settings > Pages. En "Branch" elegí `main` y la carpeta `/ (root)`, y guardá.
5. En un par de minutos la app queda en `https://TU-USUARIO.github.io/fichero-barras/`.

## Cómo instalarla en el celular

- Android (Chrome): abrí el enlace y tocá "Instalar la app" (o el menú de los tres puntos > "Instalar app").
- iPhone (Safari): abrí el enlace, tocá Compartir y elegí "Agregar a inicio".

La cámara en vivo solo funciona con https, y GitHub Pages ya lo incluye.
La primera vez hace falta internet para que se guarde el lector de códigos; después abre sin conexión.

## Si cambiás algún archivo

Subí el número de `VERSION` en `sw.js` para que los celulares reciban la actualización.
